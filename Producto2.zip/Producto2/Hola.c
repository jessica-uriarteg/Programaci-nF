#include <stdio.h>

int main()
{
    printf("Hola! Tratare de adivinar un numero.\n");
    printf("Piensa en un numero entre 1 y 10.\n");
    sleep(5);
    printf("Ahora multiplicalo por 9.\n");
    sleep(5);
    printf("Si el numero tiene dos digitos, sumalos entre si. Si tu numero tiene un solo digito sumale 0.\n");
    sleep(5);
    printf("Al numero resultante sumale 4.\n");
    sleep(10);
    printf("Muy bien! El resultado es 13;D");


    return 0;
}

