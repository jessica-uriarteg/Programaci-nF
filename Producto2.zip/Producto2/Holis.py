# Hello World program in Python
import time
    
print "Hola! Tratare de adivinar un numero."
print "Piensa un numero entre 1 y 10."
time.sleep(5)
print "Ahora multiplicalo por 9."
time.sleep(5)
print "Si el numero tiene 2 digito, sumalos entre si. Si tu numero tiene un digito, sumale 0."
time.sleep(5)
print "Al numero resultante sumale 4."
time.sleep(10)
print "Muy bien. El resultado es 13 :D ."