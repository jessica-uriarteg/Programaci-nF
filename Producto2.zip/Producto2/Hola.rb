# Hello World Program in Ruby
puts "Hola! Tratare de adivinar un numero";
puts "Piensa un numero entre 1 y 10";
sleep 5
puts "Ahora multiplicalo por 9";
sleep 5
puts "Si el numero tiene 2 digitos, sumalos entre si. Si  tu numero tiene un solo digito, sumale 0."
sleep 5
puts "Al numero resultante sumale 4.";
sleep 10
puts "Muy bien. El resultado es 13 :D! ";